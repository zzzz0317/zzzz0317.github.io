$().ready(function(){
	$.get("https://sslapi.hitokoto.cn/?encode=text&c=g",function(result){
		var famousperson=["爱因斯坦","牛顿","爱迪生","孔子","伽利略","法拉第","贝多芬","卢瑟福","达尔文","林肯","丘吉尔","杜鲁门","拿破仑","艾森豪威尔","金三胖","苏格拉底","柏拉图","亚里士多德","卓别林","毕加索","马克·吐温","但丁","海明威","纪晓岚"];
		iziToast.show({
			class: 'test',
			color: 'dark',
			icon: 'icon-contacts',
			title: result + " —— " + famousperson[Math.floor(Math.random()*famousperson.length)] + "没说过这句话",
			message: "",
			position: 'topCenter',
			progressBarColor: 'rgb(0, 255, 184)',
			transitionIn: 'bounceInDown',
			transitionOut: 'flipOutX',
			layout:2,
			timeout: 5000,
			onClose: function(){
				console.info('onClose');
			},
			iconColor: 'rgb(0, 255, 184)'
		});
	});
});